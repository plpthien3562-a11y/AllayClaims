package com.allayclaims.claims;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public final class ClaimManager {
    private final Map<UUID, Claim> claims = new HashMap<>();
    private final Map<UUID, PlayerData> players = new HashMap<>();
    private final Map<String, List<Claim>> worldIndex = new HashMap<>();

    private final File dataFile;
    private final int maxClaimBlocks;
    private final int startingClaimBlocks;
    private final int minWidth;
    private final int minHeight;
    private final boolean explosionsDefault;
    private final boolean blockExplosionsUnclaimed;
    private final boolean allowPistonsUnclaimed;
    private final boolean allowRedstoneUnclaimed;
    private final Set<String> claimableWorlds = new HashSet<>();
    private final Set<String> unclaimableWorlds = new HashSet<>();

    public ClaimManager(File dataFolder, int maxBlocks, int startingBlocks, int minW, int minH,
                        boolean explDefault, boolean blockExplUnclaimed,
                        boolean allowPistonsUnclaimed, boolean allowRedstoneUnclaimed,
                        List<String> claimable, List<String> unclaimable) {
        this.dataFile = new File(dataFolder, "data.yml");
        this.maxClaimBlocks = maxBlocks;
        this.startingClaimBlocks = startingBlocks;
        this.minWidth = minW; this.minHeight = minH;
        this.explosionsDefault = explDefault;
        this.blockExplosionsUnclaimed = blockExplUnclaimed;
        this.allowPistonsUnclaimed = allowPistonsUnclaimed;
        this.allowRedstoneUnclaimed = allowRedstoneUnclaimed;
        for (String w : claimable) this.claimableWorlds.add(w.toLowerCase());
        for (String w : unclaimable) this.unclaimableWorlds.add(w.toLowerCase());
    }

    public int maxClaimBlocks() { return maxClaimBlocks; }
    public int startingClaimBlocks() { return startingClaimBlocks; }
    public int minWidth() { return minWidth; }
    public int minHeight() { return minHeight; }
    public boolean blockExplosionsUnclaimed() { return blockExplosionsUnclaimed; }
    public boolean allowPistonsUnclaimed() { return allowPistonsUnclaimed; }
    public boolean allowRedstoneUnclaimed() { return allowRedstoneUnclaimed; }

    public boolean isWorldClaimable(String world) {
        String w = world.toLowerCase();
        if (unclaimableWorlds.contains(w)) return false;
        if (claimableWorlds.isEmpty()) return true;
        return claimableWorlds.contains(w);
    }

    public PlayerData getOrCreatePlayer(UUID id) {
        return players.computeIfAbsent(id, p -> new PlayerData(p, startingClaimBlocks));
    }

    public Claim getClaimAt(String world, int x, int z) {
        List<Claim> list = worldIndex.get(world);
        if (list == null) return null;
        for (Claim c : list) if (c.contains(world, x, z)) return c;
        return null;
    }

    public List<Claim> getClaimsOf(UUID owner) {
        PlayerData pd = players.get(owner);
        if (pd == null) return List.of();
        List<Claim> result = new ArrayList<>();
        for (UUID id : pd.claimIds()) { Claim c = claims.get(id); if (c != null) result.add(c); }
        return result;
    }

    public Collection<Claim> allClaims() { return claims.values(); }

    public int usedBlocks(UUID owner) {
        int total = 0;
        for (Claim c : getClaimsOf(owner)) total += c.area();
        return total;
    }

    public int availableBlocks(UUID owner) {
        return getOrCreatePlayer(owner).claimBlocks() - usedBlocks(owner);
    }

    public CreateResult createClaim(UUID owner, String world, int x1, int z1, int x2, int z2) {
        Claim temp = new Claim(UUID.randomUUID(), owner, world, x1, z1, x2, z2);
        int w = Math.abs(temp.x2() - temp.x1()) + 1, h = Math.abs(temp.z2() - temp.z1()) + 1;
        if (w < minWidth || h < minHeight)
            return new CreateResult(null, "claim-too-small", "min_w", minWidth, "min_h", minHeight);
        for (Claim other : claims.values())
            if (temp.overlaps(other)) return new CreateResult(null, "claim-overlaps");
        int area = temp.area();
        if (availableBlocks(owner) < area)
            return new CreateResult(null, "not-enough-blocks", "needed", area, "available", availableBlocks(owner));
        claims.put(temp.id(), temp);
        getOrCreatePlayer(owner).addClaim(temp.id());
        index(temp);
        return new CreateResult(temp, null);
    }

    public boolean deleteClaim(Claim c) {
        if (claims.remove(c.id()) == null) return false;
        unindex(c);
        PlayerData pd = players.get(c.owner());
        if (pd != null) pd.removeClaim(c.id());
        return true;
    }

    public int deleteAllClaims(UUID owner) {
        int n = 0;
        for (Claim c : getClaimsOf(owner)) if (deleteClaim(c)) n++;
        return n;
    }

    private void index(Claim c) { worldIndex.computeIfAbsent(c.world(), k -> new ArrayList<>()).add(c); }
    private void unindex(Claim c) { List<Claim> l = worldIndex.get(c.world()); if (l != null) l.remove(c); }

    public void load() {
        if (!dataFile.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection ps = cfg.getConfigurationSection("players");
        if (ps != null) for (String key : ps.getKeys(false)) {
            UUID id = UUID.fromString(key);
            players.put(id, new PlayerData(id, ps.getInt(key + ".blocks", startingClaimBlocks)));
        }
        ConfigurationSection cs = cfg.getConfigurationSection("claims");
        if (cs != null) for (String key : cs.getKeys(false)) {
            ConfigurationSection c = cs.getConfigurationSection(key);
            Claim claim = new Claim(UUID.fromString(key), UUID.fromString(c.getString("owner")),
                    c.getString("world"), c.getInt("x1"), c.getInt("z1"), c.getInt("x2"), c.getInt("z2"));
            claim.setExplosionsEnabled(c.getBoolean("explosions", explosionsDefault));
            for (String t : c.getStringList("trusted")) try { claim.trust(UUID.fromString(t)); } catch (Exception ignored) {}
            claims.put(claim.id(), claim);
            getOrCreatePlayer(claim.owner()).addClaim(claim.id());
            index(claim);
        }
    }

    public void save() {
        FileConfiguration cfg = new YamlConfiguration();
        for (var e : players.entrySet()) cfg.set("players." + e.getKey() + ".blocks", e.getValue().claimBlocks());
        for (Claim c : claims.values()) {
            String b = "claims." + c.id();
            cfg.set(b + ".owner", c.owner().toString());
            cfg.set(b + ".world", c.world());
            cfg.set(b + ".x1", c.x1()); cfg.set(b + ".z1", c.z1());
            cfg.set(b + ".x2", c.x2()); cfg.set(b + ".z2", c.z2());
            cfg.set(b + ".explosions", c.explosionsEnabled());
            List<String> tr = new ArrayList<>(); for (UUID t : c.trusted()) tr.add(t.toString());
            cfg.set(b + ".trusted", tr);
        }
        try { cfg.save(dataFile); } catch (IOException ignored) {}
    }

    public record CreateResult(Claim claim, String error, Object... args) {}
}
