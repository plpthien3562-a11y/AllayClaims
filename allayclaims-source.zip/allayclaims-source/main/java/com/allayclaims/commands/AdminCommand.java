package com.allayclaims.commands;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.PlayerData;

public final class AdminCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public AdminCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.isOp()) { sender.sendMessage(plugin.getMessageManager().prefixed("admin-no-permission")); return true; }
        if (args.length == 0) {
            sender.sendMessage(plugin.getMessageManager().get("admin-usage"));
            sender.sendMessage(plugin.getMessageManager().get("admin-delete-usage"));
            sender.sendMessage(plugin.getMessageManager().get("admin-give-usage"));
            sender.sendMessage(plugin.getMessageManager().get("admin-take-usage"));
            sender.sendMessage(plugin.getMessageManager().get("admin-ignore-usage"));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "delete" -> handleDelete(sender, args);
            case "give" -> handleGiveTake(sender, args, true);
            case "take" -> handleGiveTake(sender, args, false);
            case "ignore" -> handleIgnore(sender);
            default -> sender.sendMessage(plugin.getMessageManager().prefixed("admin-unknown-sub"));
        }
        return true;
    }
    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) { sender.sendMessage(plugin.getMessageManager().get("admin-delete-usage")); return; }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        int n = plugin.getClaimManager().deleteAllClaims(target.getUniqueId());
        sender.sendMessage(plugin.getMessageManager().prefixed("admin-delete-success", "count", n, "player", args[1]));
    }
    private void handleGiveTake(CommandSender sender, String[] args, boolean give) {
        if (args.length < 3) { sender.sendMessage(plugin.getMessageManager().get(give ? "admin-give-usage" : "admin-take-usage")); return; }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        int amount;
        try { amount = Integer.parseInt(args[2]); }
        catch (NumberFormatException e) { sender.sendMessage(plugin.getMessageManager().prefixed("amount-must-be-number")); return; }
        PlayerData pd = plugin.getClaimManager().getOrCreatePlayer(target.getUniqueId());
        pd.addBlocks(give ? amount : -amount);
        sender.sendMessage(plugin.getMessageManager().prefixed(give ? "admin-give-success" : "admin-take-success", "amount", Math.abs(amount), "player", args[1], "total", pd.claimBlocks()));
    }
    private void handleIgnore(CommandSender sender) {
        if (!(sender instanceof Player)) { sender.sendMessage(plugin.getMessageManager().prefixed("admin-player-only")); return; }
        sender.sendMessage(plugin.getMessageManager().prefixed("admin-ignore-info"));
    }
}
