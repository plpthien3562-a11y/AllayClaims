package com.allayclaims.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.Claim;

public final class ClaimExplosionCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public ClaimExplosionCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage(plugin.getMessageManager().prefixed("players-only")); return true; }
        Claim c = plugin.getClaimManager().getClaimAt(p.getWorld().getName(), p.getLocation().getBlockX(), p.getLocation().getBlockZ());
        if (c == null) { p.sendMessage(plugin.getMessageManager().prefixed("not-in-claim")); return true; }
        if (!c.owner().equals(p.getUniqueId())) { p.sendMessage(plugin.getMessageManager().prefixed("not-claim-owner")); return true; }
        c.setExplosionsEnabled(!c.explosionsEnabled());
        p.sendMessage(plugin.getMessageManager().prefixed(c.explosionsEnabled() ? "explosion-enabled" : "explosion-disabled"));
        return true;
    }
}
