package com.allayclaims.listeners;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.Claim;
import com.allayclaims.claims.ClaimManager;

public final class ProtectionListener implements Listener {
    private final AllayClaims plugin;
    public ProtectionListener(AllayClaims plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (event.getPlayer().isOp()) return;
        Claim c = plugin.getClaimManager().getClaimAt(event.getBlock().getWorld().getName(), event.getBlock().getX(), event.getBlock().getZ());
        if (c == null || c.canAccess(event.getPlayer().getUniqueId())) return;
        event.setCancelled(true);
        event.getPlayer().sendMessage(plugin.getMessageManager().prefixed("not-in-claim"));
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (event.getPlayer().isOp()) return;
        Claim c = plugin.getClaimManager().getClaimAt(event.getBlock().getWorld().getName(), event.getBlock().getX(), event.getBlock().getZ());
        if (c == null || c.canAccess(event.getPlayer().getUniqueId())) return;
        event.setCancelled(true);
        event.getPlayer().sendMessage(plugin.getMessageManager().prefixed("not-in-claim"));
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() == null) return;
        if (event.getPlayer().isOp()) return;
        Material item = event.getPlayer().getInventory().getItemInMainHand().getType();
        Material claimTool = Material.matchMaterial(plugin.getConfig().getString("claim-tool", "GOLDEN_SHOVEL"));
        if (item == claimTool) return;
        Claim c = plugin.getClaimManager().getClaimAt(event.getClickedBlock().getWorld().getName(), event.getClickedBlock().getX(), event.getClickedBlock().getZ());
        if (c == null || c.canAccess(event.getPlayer().getUniqueId())) return;
        event.setCancelled(true);
        event.getPlayer().sendMessage(plugin.getMessageManager().prefixed("not-in-claim"));
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent event) {
        ClaimManager mgr = plugin.getClaimManager();
        event.blockList().removeIf(block -> {
            Claim c = mgr.getClaimAt(block.getWorld().getName(), block.getX(), block.getZ());
            if (c != null) return !c.explosionsEnabled();
            return mgr.blockExplosionsUnclaimed();
        });
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        handlePiston(event.getBlock(), event.getBlocks(), event);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        handlePiston(event.getBlock(), event.getBlocks(), event);
    }

    private void handlePiston(Block piston, java.util.List<Block> affected, org.bukkit.event.Cancellable event) {
        ClaimManager mgr = plugin.getClaimManager();
        String world = piston.getWorld().getName();
        Claim pistonClaim = mgr.getClaimAt(world, piston.getX(), piston.getZ());
        if (pistonClaim == null && mgr.allowPistonsUnclaimed()) return;
        for (Block b : affected) {
            Claim targetClaim = mgr.getClaimAt(world, b.getX(), b.getZ());
            if (targetClaim != pistonClaim) { event.setCancelled(true); return; }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onRedstone(BlockRedstoneEvent event) {
        Block b = event.getBlock();
        ClaimManager mgr = plugin.getClaimManager();
        Claim c = mgr.getClaimAt(b.getWorld().getName(), b.getX(), b.getZ());
        if (c == null && mgr.allowRedstoneUnclaimed()) return;
        if (c == null) { event.setNewCurrent(0); return; }
    }
}
