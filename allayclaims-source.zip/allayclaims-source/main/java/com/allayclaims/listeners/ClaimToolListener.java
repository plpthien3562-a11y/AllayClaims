package com.allayclaims.listeners;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitRunnable;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.Claim;
import com.allayclaims.claims.ClaimManager;
import com.allayclaims.claims.ClaimManager.CreateResult;
import com.allayclaims.visual.Visualization;

public final class ClaimToolListener implements Listener {

    private final AllayClaims plugin;
    private final Map<UUID, int[]> firstCorners = new HashMap<>();
    private final Map<UUID, Visualization> activeVis = new HashMap<>();
    private final Map<UUID, Integer> visTasks = new HashMap<>();

    public ClaimToolListener(AllayClaims plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        Material tool = player.getInventory().getItemInMainHand().getType();
        Material claimTool = Material.matchMaterial(plugin.getConfig().getString("claim-tool", "GOLDEN_SHOVEL"));
        if (tool != claimTool) return;

        event.setCancelled(true);
        Block clicked = event.getClickedBlock();
        UUID id = player.getUniqueId();
        String world = clicked.getWorld().getName();

        if (!plugin.getClaimManager().isWorldClaimable(world)) {
            player.sendMessage(plugin.getMessageManager().prefixed("world-not-claimable"));
            return;
        }

        Claim existing = plugin.getClaimManager().getClaimAt(world, clicked.getX(), clicked.getZ());
        if (existing != null) {
            clearVisualization(player);
            showClaimFrame(player, existing);
            OfflinePlayer owner = Bukkit.getOfflinePlayer(existing.owner());
            String name = owner.getName() != null ? owner.getName() : "Unknown";
            player.sendMessage(plugin.getMessageManager().prefixed("already-claimed", "player", name));
            return;
        }

        int[] first = firstCorners.get(id);
        if (first == null) {
            clearVisualization(player);
            firstCorners.put(id, new int[]{clicked.getX(), clicked.getZ()});
            Visualization vis = Visualization.forSingleBlock(clicked.getLocation());
            vis.show(player, getVisMaterial());
            activeVis.put(id, vis);
            player.sendMessage(plugin.getMessageManager().prefixed("first-corner-set", "x", clicked.getX(), "z", clicked.getZ()));
        } else {
            firstCorners.remove(id);
            clearVisualization(player);
            createClaim(player, clicked, first[0], first[1]);
        }
    }

    private void createClaim(Player player, Block block, int x1, int z1) {
        int x2 = block.getX(), z2 = block.getZ();
        String world = block.getWorld().getName();
        UUID owner = player.getUniqueId();
        ClaimManager mgr = plugin.getClaimManager();

        CreateResult result = mgr.createClaim(owner, world, x1, z1, x2, z2);
        if (result.error() != null) {
            player.sendMessage(plugin.getMessageManager().prefixed(result.error(), result.args()));
        } else {
            Claim c = result.claim();
            player.sendMessage(plugin.getMessageManager().prefixed("claim-created", "area", c.area(), "remaining", mgr.availableBlocks(owner)));
            showClaimFrame(player, c);
        }
    }

    private void showClaimFrame(Player player, Claim c) {
        Material mat = getVisMaterial();
        int baseY = player.getLocation().getBlockY() - 1;
        Visualization vis = Visualization.forClaimFrame(
                player.getWorld(), c.x1(), c.z1(), c.x2(), c.z2(), baseY);
        vis.show(player, mat);
        activeVis.put(player.getUniqueId(), vis);
        scheduleHide(player.getUniqueId(), plugin.getConfig().getInt("visualization-duration", 30));
    }

    private void scheduleHide(UUID playerId, int seconds) {
        Integer existing = visTasks.get(playerId);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);
        int taskId = new BukkitRunnable() {
            @Override public void run() {
                Player p = plugin.getServer().getPlayer(playerId);
                if (p != null) clearVisualization(p);
                else activeVis.remove(playerId);
                visTasks.remove(playerId);
            }
        }.runTaskLater(plugin, seconds * 20L).getTaskId();
        visTasks.put(playerId, taskId);
    }

    private void clearVisualization(Player player) {
        Visualization old = activeVis.remove(player.getUniqueId());
        if (old != null) old.hide(player);
        Integer task = visTasks.remove(player.getUniqueId());
        if (task != null) plugin.getServer().getScheduler().cancelTask(task);
    }

    private Material getVisMaterial() {
        return Material.matchMaterial(plugin.getConfig().getString("visualization-block", "GLOWSTONE"));
    }

    public void clearPlayer(UUID playerId) {
        firstCorners.remove(playerId);
        activeVis.remove(playerId);
        visTasks.remove(playerId);
    }
}
