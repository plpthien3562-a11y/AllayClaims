package com.allayclaims.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import com.allayclaims.AllayClaims;

public final class InfoCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public InfoCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String version = plugin.getDescription().getVersion();
        sender.sendMessage(plugin.getMessageManager().get("info-title"));
        sender.sendMessage(plugin.getMessageManager().get("info-version", "version", version));
        sender.sendMessage(plugin.getMessageManager().get("info-author"));
        sender.sendMessage(plugin.getMessageManager().get("info-description"));
        sender.sendMessage(plugin.getMessageManager().get("info-link"));
        sender.sendMessage(plugin.getMessageManager().get("info-copyright"));
        sender.sendMessage(plugin.getMessageManager().get("info-mit"));
        sender.sendMessage(plugin.getMessageManager().get("info-footer"));
        return true;
    }
}
