package com.allayclaims.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;

public final class UnallclaimCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public UnallclaimCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage(plugin.getMessageManager().prefixed("players-only")); return true; }
        int n = plugin.getClaimManager().deleteAllClaims(p.getUniqueId());
        p.sendMessage(plugin.getMessageManager().prefixed(n == 0 ? "unallclaim-none" : "unallclaim-success", "count", n));
        return true;
    }
}
