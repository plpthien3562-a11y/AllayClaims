package com.allayclaims.commands;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.Claim;

public final class UntrustCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public UntrustCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage(plugin.getMessageManager().prefixed("players-only")); return true; }
        if (args.length != 1) { p.sendMessage(plugin.getMessageManager().prefixed("untrust-usage")); return true; }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        Claim c = plugin.getClaimManager().getClaimAt(p.getWorld().getName(), p.getLocation().getBlockX(), p.getLocation().getBlockZ());
        if (c == null) { p.sendMessage(plugin.getMessageManager().prefixed("not-in-claim")); return true; }
        if (!c.owner().equals(p.getUniqueId())) { p.sendMessage(plugin.getMessageManager().prefixed("not-claim-owner")); return true; }
        c.untrust(target.getUniqueId());
        p.sendMessage(plugin.getMessageManager().prefixed("untrust-success", "player", args[0]));
        return true;
    }
}
