package com.allayclaims.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.PlayerData;
import com.allayclaims.economy.EconomyManager;

public final class SellClaimBlocksCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public SellClaimBlocksCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage(plugin.getMessageManager().prefixed("players-only")); return true; }
        if (!plugin.hasEconomy()) { p.sendMessage(plugin.getMessageManager().prefixed("economy-not-available")); return true; }
        if (args.length != 1) { p.sendMessage(plugin.getMessageManager().prefixed("sell-usage")); return true; }
        int amount;
        try { amount = Integer.parseInt(args[0]); }
        catch (NumberFormatException e) { p.sendMessage(plugin.getMessageManager().prefixed("amount-must-be-number")); return true; }
        if (amount <= 0) { p.sendMessage(plugin.getMessageManager().prefixed("amount-must-be-positive")); return true; }
        EconomyManager econ = plugin.getEconomyManager();
        PlayerData pd = plugin.getClaimManager().getOrCreatePlayer(p.getUniqueId());
        int available = pd.claimBlocks() - plugin.getClaimManager().usedBlocks(p.getUniqueId());
        if (amount > available) { p.sendMessage(plugin.getMessageManager().prefixed("sell-not-enough-blocks", "available", available)); return true; }
        double money = amount * econ.sellPrice();
        pd.addBlocks(-amount);
        if (!econ.deposit(p.getUniqueId(), money)) { pd.addBlocks(amount); p.sendMessage(plugin.getMessageManager().prefixed("transaction-failed")); return true; }
        p.sendMessage(plugin.getMessageManager().prefixed("sell-success", "amount", amount, "money", money, "remaining", pd.claimBlocks()));
        return true;
    }
}
