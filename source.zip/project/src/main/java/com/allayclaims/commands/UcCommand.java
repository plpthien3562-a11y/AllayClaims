package com.allayclaims.commands;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.Claim;

public final class UcCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public UcCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage(plugin.getMessageManager().prefixed("players-only")); return true; }
        Claim c = plugin.getClaimManager().getClaimAt(p.getWorld().getName(), p.getLocation().getBlockX(), p.getLocation().getBlockZ());
        if (c == null) { p.sendMessage(plugin.getMessageManager().prefixed("uc-no-claim")); return true; }
        int area = c.area();
        OfflinePlayer owner = Bukkit.getOfflinePlayer(c.owner());
        String ownerName = owner.getName() != null ? owner.getName() : "Unknown";
        plugin.getClaimManager().deleteClaim(c);
        p.sendMessage(plugin.getMessageManager().prefixed("uc-success", "player", ownerName, "area", area));
        return true;
    }
}
