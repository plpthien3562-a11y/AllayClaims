package com.allayclaims.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.Claim;

public final class UnclaimCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public UnclaimCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage(plugin.getMessageManager().prefixed("players-only")); return true; }
        Claim c = plugin.getClaimManager().getClaimAt(p.getWorld().getName(), p.getLocation().getBlockX(), p.getLocation().getBlockZ());
        if (c == null) { p.sendMessage(plugin.getMessageManager().prefixed("not-in-claim")); return true; }
        if (!c.owner().equals(p.getUniqueId()) && !p.hasPermission("allayclaims.admin")) { p.sendMessage(plugin.getMessageManager().prefixed("not-claim-owner")); return true; }
        int area = c.area();
        plugin.getClaimManager().deleteClaim(c);
        p.sendMessage(plugin.getMessageManager().prefixed("unclaim-success", "area", area));
        return true;
    }
}
