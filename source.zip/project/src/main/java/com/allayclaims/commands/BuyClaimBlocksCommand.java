package com.allayclaims.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.PlayerData;
import com.allayclaims.economy.EconomyManager;

public final class BuyClaimBlocksCommand implements CommandExecutor {
    private final AllayClaims plugin;
    public BuyClaimBlocksCommand(AllayClaims plugin) { this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage(plugin.getMessageManager().prefixed("players-only")); return true; }
        if (!plugin.hasEconomy()) { p.sendMessage(plugin.getMessageManager().prefixed("economy-not-available")); return true; }
        if (args.length != 1) { p.sendMessage(plugin.getMessageManager().prefixed("buy-usage")); return true; }
        int amount;
        try { amount = Integer.parseInt(args[0]); }
        catch (NumberFormatException e) { p.sendMessage(plugin.getMessageManager().prefixed("amount-must-be-number")); return true; }
        if (amount <= 0) { p.sendMessage(plugin.getMessageManager().prefixed("amount-must-be-positive")); return true; }
        EconomyManager econ = plugin.getEconomyManager();
        PlayerData pd = plugin.getClaimManager().getOrCreatePlayer(p.getUniqueId());
        int max = econ.maxBlocks();
        if (pd.claimBlocks() + amount > max) { p.sendMessage(plugin.getMessageManager().prefixed("buy-exceeds-max", "max", max)); return true; }
        double cost = amount * econ.buyPrice();
        if (!econ.has(p.getUniqueId(), cost)) { p.sendMessage(plugin.getMessageManager().prefixed("buy-not-enough-money", "cost", cost)); return true; }
        if (!econ.withdraw(p.getUniqueId(), cost)) { p.sendMessage(plugin.getMessageManager().prefixed("transaction-failed")); return true; }
        pd.addBlocks(amount);
        p.sendMessage(plugin.getMessageManager().prefixed("buy-success", "amount", amount, "cost", cost, "total", pd.claimBlocks()));
        return true;
    }
}
