package com.allayclaims.listeners;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import com.allayclaims.AllayClaims;
import com.allayclaims.claims.Claim;

public final class PlayerMoveListener implements Listener {
    private final AllayClaims plugin;
    private final Map<UUID, UUID> lastClaim = new HashMap<>();

    public PlayerMoveListener(AllayClaims plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Claim current = plugin.getClaimManager().getClaimAt(
                event.getTo().getWorld().getName(), event.getTo().getBlockX(), event.getTo().getBlockZ());
        UUID lastId = lastClaim.get(playerId);
        UUID currentId = current != null ? current.id() : null;
        if (currentId == null && lastId != null) { lastClaim.remove(playerId); return; }
        if (currentId != null && !currentId.equals(lastId)) {
            lastClaim.put(playerId, currentId);
            sendClaimTitle(player, current);
        }
    }

    private void sendClaimTitle(Player player, Claim claim) {
        String title;
        if (claim.owner().equals(player.getUniqueId())) {
            title = plugin.getMessageManager().get("title-own-claim");
        } else {
            OfflinePlayer owner = Bukkit.getOfflinePlayer(claim.owner());
            String name = owner.getName() != null ? owner.getName() : "Unknown";
            title = plugin.getMessageManager().get("title-other-claim", "player", name);
        }
        String subtitle = plugin.getMessageManager().get("title-subtitle");
        player.sendTitle(title, subtitle, 10, 40, 10);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) { lastClaim.remove(event.getPlayer().getUniqueId()); }
}
