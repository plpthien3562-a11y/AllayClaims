package com.allayclaims.placeholder;

import org.bukkit.entity.Player;

import com.allayclaims.AllayClaims;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;

public final class ClaimBlocksExpansion extends PlaceholderExpansion {
    private final AllayClaims plugin;

    public ClaimBlocksExpansion(AllayClaims plugin) { this.plugin = plugin; }

    @Override public String getIdentifier() { return "allayclaims"; }
    @Override public String getAuthor() { return "AllayMC"; }
    @Override public String getVersion() { return "1.0.0"; }
    @Override public boolean persist() { return true; }

    @Override
    public String onPlaceholderRequest(Player player, String params) {
        if (player == null) return "";
        if (params.equalsIgnoreCase("claim_block")) {
            return String.valueOf(plugin.getClaimManager().availableBlocks(player.getUniqueId()));
        }
        return null;
    }
}
