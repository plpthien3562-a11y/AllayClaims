package com.allayclaims;

import java.io.File;
import java.util.List;

import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import com.allayclaims.claims.ClaimManager;
import com.allayclaims.commands.AdminCommand;
import com.allayclaims.commands.BuyClaimBlocksCommand;
import com.allayclaims.commands.ClaimExplosionCommand;
import com.allayclaims.commands.InfoCommand;
import com.allayclaims.commands.SellClaimBlocksCommand;
import com.allayclaims.commands.TrustCommand;
import com.allayclaims.commands.UcCommand;
import com.allayclaims.commands.UnallclaimCommand;
import com.allayclaims.commands.UnclaimCommand;
import com.allayclaims.commands.UntrustCommand;
import com.allayclaims.economy.EconomyManager;
import com.allayclaims.listeners.ClaimToolListener;
import com.allayclaims.listeners.PlayerMoveListener;
import com.allayclaims.listeners.ProtectionListener;
import com.allayclaims.messages.MessageManager;
import com.allayclaims.placeholder.ClaimBlocksExpansion;

import net.milkbowl.vault.economy.Economy;

public final class AllayClaims extends JavaPlugin {
    private ClaimManager claimManager;
    private EconomyManager economyManager;
    private MessageManager messageManager;
    private ClaimToolListener claimToolListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("messages.yml", false);

        int maxBlocks = getConfig().getInt("max-claim-blocks", 10000);
        int startingBlocks = getConfig().getInt("starting-claim-blocks", 1000);
        int minW = getConfig().getInt("min-claim-width", 5);
        int minH = getConfig().getInt("min-claim-height", 5);
        boolean explDefault = getConfig().getBoolean("explosions-enabled-by-default", false);
        boolean blockExplUnclaimed = getConfig().getBoolean("block-explosions-in-unclaimed", true);
        List<String> claimable = getConfig().getStringList("claimable-worlds");
        List<String> unclaimable = getConfig().getStringList("unclaimable-worlds");

        claimManager = new ClaimManager(getDataFolder(), maxBlocks, startingBlocks, minW, minH,
                explDefault, blockExplUnclaimed, claimable, unclaimable);
        claimManager.load();

        messageManager = new MessageManager(getDataFolder());
        messageManager.load(new File(getDataFolder(), "messages.yml"));

        if (getServer().getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp != null) {
                boolean econEnabled = getConfig().getBoolean("economy.enabled", true);
                double buyPrice = getConfig().getDouble("economy.buy-price", 1.0);
                double sellPrice = getConfig().getDouble("economy.sell-price", 0.5);
                economyManager = new EconomyManager(rsp.getProvider(), buyPrice, sellPrice, econEnabled, maxBlocks);
            }
        }

        claimToolListener = new ClaimToolListener(this);
        getServer().getPluginManager().registerEvents(claimToolListener, this);
        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerMoveListener(this), this);

        getCommand("trust").setExecutor(new TrustCommand(this));
        getCommand("untrust").setExecutor(new UntrustCommand(this));
        getCommand("unclaim").setExecutor(new UnclaimCommand(this));
        getCommand("uc").setExecutor(new UcCommand(this));
        getCommand("unallclaim").setExecutor(new UnallclaimCommand(this));
        getCommand("claimexplosion").setExecutor(new ClaimExplosionCommand(this));
        getCommand("bbclaim").setExecutor(new AdminCommand(this));
        getCommand("buyclaimblocks").setExecutor(new BuyClaimBlocksCommand(this));
        getCommand("sellclaimblocks").setExecutor(new SellClaimBlocksCommand(this));
        getCommand("allayclaims").setExecutor(new InfoCommand(this));

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new ClaimBlocksExpansion(this).register();
        }

        getLogger().info("AllayClaims v1.0.0 enabled.");
    }

    @Override
    public void onDisable() {
        if (claimManager != null) claimManager.save();
        getLogger().info("AllayClaims disabled.");
    }

    public ClaimManager getClaimManager() { return claimManager; }
    public EconomyManager getEconomyManager() { return economyManager; }
    public MessageManager getMessageManager() { return messageManager; }
    public boolean hasEconomy() { return economyManager != null && economyManager.isEnabled(); }
}
