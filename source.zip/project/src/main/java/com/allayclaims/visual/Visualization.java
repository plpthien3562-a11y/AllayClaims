package com.allayclaims.visual;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;

public final class Visualization {

    private final List<VisualBlock> blocks = new ArrayList<>();

    private record VisualBlock(Location loc, BlockData realData) {}

    private void add(Location loc) {
        Block b = loc.getBlock();
        blocks.add(new VisualBlock(loc.clone(), b.getBlockData()));
    }

    public void show(Player player, Material material) {
        BlockData fake = material.createBlockData();
        for (VisualBlock vb : blocks) player.sendBlockChange(vb.loc(), fake);
    }

    public void hide(Player player) {
        for (VisualBlock vb : blocks) player.sendBlockChange(vb.loc(), vb.realData());
    }

    public static Visualization forClaimFrame(World world, int x1, int z1, int x2, int z2, int baseY) {
        Visualization vis = new Visualization();
        int minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
        int minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);

        for (int x = minX; x <= maxX; x++) {
            vis.add(new Location(world, x, baseY, minZ));
            vis.add(new Location(world, x, baseY, maxZ));
        }
        for (int z = minZ + 1; z < maxZ; z++) {
            vis.add(new Location(world, minX, baseY, z));
            vis.add(new Location(world, maxX, baseY, z));
        }

        return vis;
    }

    public static Visualization forSingleBlock(Location loc) {
        Visualization vis = new Visualization();
        vis.add(loc);
        return vis;
    }
}
