package com.allayclaims.messages;

import java.io.File;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public final class MessageManager {
    private final File messagesFile;
    private final String prefix;
    private final Map<String, String> messages = new HashMap<>();

    public MessageManager(File dataFolder) {
        this.messagesFile = new File(dataFolder, "messages.yml");
        this.prefix = "&8[&bAllayClaims&8] &r";
    }

    public void load(File defaultConfigFile) {
        if (!messagesFile.exists()) {
            messagesFile.getParentFile().mkdirs();
            try { Files.copy(defaultConfigFile.toPath(), messagesFile.toPath()); } catch (Exception ignored) {}
        }
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(messagesFile);
        for (String key : cfg.getKeys(true)) if (cfg.isString(key)) messages.put(key, cfg.getString(key));
    }

    public String get(String key, Object... args) {
        String msg = messages.getOrDefault(key, "");
        if (args.length > 0 && args.length % 2 == 0)
            for (int i = 0; i < args.length; i += 2)
                msg = msg.replace("{" + args[i] + "}", String.valueOf(args[i + 1]));
        return ChatColor.translateAlternateColorCodes('&', msg);
    }

    public String prefixed(String key, Object... args) {
        return ChatColor.translateAlternateColorCodes('&', prefix) + get(key, args);
    }
}
