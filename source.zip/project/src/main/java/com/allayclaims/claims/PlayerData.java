package com.allayclaims.claims;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class PlayerData {
    private final UUID playerId;
    private int claimBlocks;
    private final Set<UUID> claimIds;

    public PlayerData(UUID playerId, int startingBlocks) {
        this.playerId = playerId; this.claimBlocks = startingBlocks; this.claimIds = new HashSet<>();
    }

    public int claimBlocks() { return claimBlocks; }
    public void addBlocks(int n) { claimBlocks = Math.max(0, claimBlocks + n); }
    public Set<UUID> claimIds() { return claimIds; }
    public void addClaim(UUID id) { claimIds.add(id); }
    public void removeClaim(UUID id) { claimIds.remove(id); }
}
