package com.allayclaims.claims;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class Claim {
    private final UUID id;
    private final UUID owner;
    private final String world;
    private int x1, z1, x2, z2;
    private boolean explosionsEnabled;
    private final Set<UUID> trusted;

    public Claim(UUID id, UUID owner, String world, int x1, int z1, int x2, int z2) {
        this.id = id; this.owner = owner; this.world = world;
        this.x1 = Math.min(x1, x2); this.z1 = Math.min(z1, z2);
        this.x2 = Math.max(x1, x2); this.z2 = Math.max(z1, z2);
        this.explosionsEnabled = false; this.trusted = new HashSet<>();
    }

    public UUID id() { return id; }
    public UUID owner() { return owner; }
    public String world() { return world; }
    public int x1() { return x1; } public int z1() { return z1; }
    public int x2() { return x2; } public int z2() { return z2; }

    public void setBounds(int nx1, int nz1, int nx2, int nz2) {
        this.x1 = Math.min(nx1, nx2); this.z1 = Math.min(nz1, nz2);
        this.x2 = Math.max(nx1, nx2); this.z2 = Math.max(nz1, nz2);
    }

    public int area() { return (x2 - x1 + 1) * (z2 - z1 + 1); }

    public boolean contains(String w, int x, int z) {
        return w.equals(world) && x >= x1 && x <= x2 && z >= z1 && z <= z2;
    }

    public boolean isCorner(int x, int z) {
        return (x == x1 || x == x2) && (z == z1 || z == z2);
    }

    public int cornerIndex(int x, int z) {
        if (x == x1 && z == z1) return 0;
        if (x == x1 && z == z2) return 1;
        if (x == x2 && z == z1) return 2;
        if (x == x2 && z == z2) return 3;
        return -1;
    }

    public boolean overlaps(Claim o) {
        return world.equals(o.world) && !(x2 < o.x1 || x1 > o.x2 || z2 < o.z1 || z1 > o.z2);
    }

    public boolean explosionsEnabled() { return explosionsEnabled; }
    public void setExplosionsEnabled(boolean v) { this.explosionsEnabled = v; }

    public Set<UUID> trusted() { return trusted; }
    public void trust(UUID p) { trusted.add(p); }
    public void untrust(UUID p) { trusted.remove(p); }
    public boolean canAccess(UUID player) { return owner.equals(player) || trusted.contains(player); }
}
