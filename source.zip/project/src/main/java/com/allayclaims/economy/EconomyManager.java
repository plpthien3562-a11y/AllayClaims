package com.allayclaims.economy;

import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import net.milkbowl.vault.economy.Economy;

public final class EconomyManager {
    private final Economy economy;
    private final double buyPrice;
    private final double sellPrice;
    private final boolean enabled;
    private final int maxBlocks;

    public EconomyManager(Economy economy, double buyPrice, double sellPrice, boolean enabled, int maxBlocks) {
        this.economy = economy; this.buyPrice = buyPrice; this.sellPrice = sellPrice;
        this.enabled = enabled; this.maxBlocks = maxBlocks;
    }

    public boolean isEnabled() { return enabled; }
    public double buyPrice() { return buyPrice; }
    public double sellPrice() { return sellPrice; }
    public int maxBlocks() { return maxBlocks; }

    public boolean has(UUID p, double amt) { return economy.has(Bukkit.getOfflinePlayer(p), amt); }
    public boolean withdraw(UUID p, double amt) { return economy.withdrawPlayer(Bukkit.getOfflinePlayer(p), amt).transactionSuccess(); }
    public boolean deposit(UUID p, double amt) { return economy.depositPlayer(Bukkit.getOfflinePlayer(p), amt).transactionSuccess(); }
}
